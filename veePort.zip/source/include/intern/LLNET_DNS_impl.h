/*
 * C
 *
 * Copyright 2014-2022 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#define LLNET_DNS_IMPL_getHostByAddr 		Java_com_is2t_support_net_natives_DNSNatives_getHostByAddr
#define LLNET_DNS_IMPL_getHostByNameAt 		Java_com_is2t_support_net_natives_DNSNatives_getHostByNameAt
#define LLNET_DNS_IMPL_getHostByNameCount 	Java_com_is2t_support_net_natives_DNSNatives_getHostByNameCount
