/* 
 * C
 * 
 * Copyright 2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */
/* 
 * This file is auto-generated - DO NOT EDIT IT
 */
/* 
 * IceTea to C mapping support. Shall not be directly included by clients.
 */
#ifndef _LLKERNEL_intern
#define _LLKERNEL_intern 
typedef struct LLKERNEL LLKERNEL;
#include <stdint.h>
#ifdef __cplusplus
	extern "C" {
#endif
#define LLKERNEL_quantaConsumed __icetea__virtual__com_is2t_kf_IKernel___quantaConsumed__I
struct LLKERNEL
{
	int32_t __icetea__id__;
};
#ifdef __cplusplus
	}
#endif
#endif
