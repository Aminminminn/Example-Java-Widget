#ifndef _microui_constants_
#define _microui_constants_ 
#ifdef __cplusplus
	extern "C" {
#endif
#define _MICROUI_EVENTGEN_DISABLED_ 0xff
#define MICROUI_EVENTGEN_TOUCH 0
#define MICROUI_EVENTGEN_BUTTONS 1
#define MICROUI_EVENTGEN_COMMANDS 2
#ifdef __cplusplus
	}
#endif
#endif
