/*
 * C
 *
 * Copyright 2020-2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#ifndef LLUI_FONT_IMPL
#define LLUI_FONT_IMPL

#ifdef __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------
// Includes
// -----------------------------------------------------------------------------

#include <sni.h>

// --------------------------------------------------------------------------------
// Defines
// --------------------------------------------------------------------------------

/**
 * Font handle value for unloaded font.
 */
#define LLVG_FONT_UNLOADED 0

/**
 * Simple layout mode, for latin scripts where only Kerning feature is needed.
 */
#define LAYOUT_SIMPLE_MODE  0

/**
 * Complex layout mode, for arabic, thai and other complex scripts where glyphs substitutions and positionning
 * features are needed.
 */
#define LAYOUT_COMPLEX_MODE 1

// --------------------------------------------------------------------------------
// MicroVG library's native functions names redefinition
// --------------------------------------------------------------------------------

#define LLVG_FONT_IMPL_load_font              Java_ej_microvg_VectorFontNatives_loadFont
#define LLVG_FONT_IMPL_string_width           Java_ej_microvg_VectorFontNatives_stringWidth
#define LLVG_FONT_IMPL_string_height          Java_ej_microvg_VectorFontNatives_stringHeight
#define LLVG_FONT_IMPL_get_baseline_position  Java_ej_microvg_VectorFontNatives_getBaselinePosition
#define LLVG_FONT_IMPL_get_height             Java_ej_microvg_VectorFontNatives_getHeight
#define LLVG_FONT_IMPL_dispose                Java_ej_microvg_VectorFontNatives_dispose
#define LLVG_FONT_IMPL_has_complex_layouter   Java_ej_microvg_VectorFontNatives_hasComplexLayouter

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions
// --------------------------------------------------------------------------------

/*
 * @brief Loads a font from a path.
 *
 * @param[in] font_name the path of the font
 * @param[in] complex_layout enable the complex layouter for that font.
 *
 * @return the reference handle of the font or 0 if the font could not be loaded.
 */
jint LLVG_FONT_IMPL_load_font(jchar *font_name, jboolean complex_layout);

/*
 * @brief Measures the width of a text for the specified font and size.
 *
 * The text is measured from first pixel of the first glyph to last pixel of the last glyph.
 *
 * @param[in] string the character string to measure
 * @param[in] faceHandle the font reference handle
 * @param[in] size the font size, in pixels
 * @param[in] letterSpacing the extra letter spacing to use
 *
 * @return the width of the specified string, in pixels or a negative error code on error.
 */
jfloat LLVG_FONT_IMPL_string_width(jchar *text, jint faceHandle, jfloat size, jfloat letterSpacing);

/*
 * @brief Measures the height of a text for the specified font and size.
 *
 * The text is measured from upper pixel of the upper glyph to the lower pixel of the lower glyph.
 *
 * @param[in] string the character string to measure
 * @param[in] faceHandle the font reference handle
 * @param[in] size the font size, in pixels
 *
 * @return the height of the specified string, in pixels or a negative error code on error.
 */
jfloat LLVG_FONT_IMPL_string_height(jchar *text, jint faceHandle, jfloat size);

/*
 * @brief Gets the baseline position for a font at the given font size.
 *
 * @param[in] faceHandle the font reference handle.
 * @param[in] size the font size, in pixels.
 *
 * @return the distance in pixel from top to the baseline position, in pixels or a negative error code on error.
 */
jfloat LLVG_FONT_IMPL_get_baseline_position(jint faceHandle, jfloat size);

/*
 * @brief Gets the height for a font at the given font size.
 *
 * The height of a font is the distance between the max ascent line and the max descent line.
 *
 * @param[in] faceHandle the font reference handle.
 * @param[in] size the height of the font in pixels.
 *
 * @return the distance from the top of the font to the bottom, in pixels or a negative error code on error.
 */
jfloat LLVG_FONT_IMPL_get_height(jint faceHandle, jfloat size);

/*
 * @brief Disposes the resources associated to the font.
 *
 * @param[in] faceHandle the font reference handle.
 */
void LLVG_FONT_IMPL_dispose(jint faceHandle);

/*
 * @brief Determines if a complex layouter is available.
 *
 * @return true if a complex layouter is available otherwise false.
 */
bool LLVG_FONT_IMPL_has_complex_layouter(void);

// -----------------------------------------------------------------------------
// EOF
// -----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif
#endif // ifndef LLUI_FONT_IMPL
