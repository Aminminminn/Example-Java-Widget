/*
 * C
 *
 * Copyright 2023-2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#if !defined LLVG_BVI_IMPL_H
#define LLVG_BVI_IMPL_H

#if defined __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------
// Includes
// -----------------------------------------------------------------------------

#include <LLUI_PAINTER_impl.h>
#include <LLVG_impl.h>

// -----------------------------------------------------------------------------
// Java library constants (static final)
// -----------------------------------------------------------------------------

/*
 * @brief Specifies the BufferedVectorImage format
 */
#define BVI_FORMAT (MICROUI_IMAGE_FORMAT_CUSTOM_7) // hardcoded in Java lib

/*
 * @brief Tells if the image is a BufferedVectorImage
 */
#define IS_BVI(image) (BVI_FORMAT == (MICROUI_ImageFormat)((image)->format))

/*
 * @brief Maps a BufferedVectorImage on a MicroUI Image
 */
#define MAP_BVI_ON_IMAGE(image) (void *)LLUI_DISPLAY_getBufferAddress((image))

/*
 * @brief Maps a BufferedVectorImage on a MicroUI GraphicsContext
 */
#define MAP_BVI_ON_GC(gc) (void *)MAP_BVI_ON_IMAGE(&((gc)->image))

// --------------------------------------------------------------------------------
// MicroVG native functions names redefinition
// --------------------------------------------------------------------------------
/*
 * @brief Macros to declare native functions
 */
#define LLVG_BVI_IMPL_map_context Java_ej_microvg_VectorGraphicsNatives_mapContext
#define LLVG_BVI_IMPL_clear Java_ej_microvg_VectorGraphicsNatives_clear

// --------------------------------------------------------------------------------
// Public API
// --------------------------------------------------------------------------------

/*
 * @brief Maps the MicroVG BufferedVectorImage on the MicroUI Image.
 *
 * @param[in] ui: the MicroUI Image.
 * @param[in] vg: the MicroVG Image.
 */
void LLVG_BVI_IMPL_map_context(MICROUI_Image *ui, MICROVG_Image *vg);

/*
 * @brief Clears the content of the BufferedVectorImage.
 *
 * @param[in] gc: the Graphics Context that holds the BufferedVectorImage.
 */
void LLVG_BVI_IMPL_clear(MICROUI_GraphicsContext *gc);

// -----------------------------------------------------------------------------
// EOF
// -----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif // !defined LLVG_BVI_IMPL_H
