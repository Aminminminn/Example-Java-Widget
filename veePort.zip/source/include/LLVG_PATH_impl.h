/*
 * C
 *
 * Copyright 2022-2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#if !defined LLVG_PATH_IMPL_H
#define LLVG_PATH_IMPL_H

#if defined __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------
// Includes
// -----------------------------------------------------------------------------

#include <sni.h>

#include <LLVG_impl.h>

// -----------------------------------------------------------------------------
// Defines
// -----------------------------------------------------------------------------

/*
 * @brief VectorGraphics library "CLOSE" command.
 */
#define LLVG_PATH_CMD_CLOSE 0

/*
 * @brief VectorGraphics library "MOVE ABS" command.
 */
#define LLVG_PATH_CMD_MOVE 1

/*
 * @brief VectorGraphics library "MOVE REL" command.
 */
#define LLVG_PATH_CMD_MOVE_REL 2

/*
 * @brief VectorGraphics library "LINE ABS" command.
 */
#define LLVG_PATH_CMD_LINE 3

/*
 * @brief VectorGraphics library "LINE REL" command.
 */
#define LLVG_PATH_CMD_LINE_REL 4

/*
 * @brief VectorGraphics library "QUAD ABS" command.
 */
#define LLVG_PATH_CMD_QUAD 5

/*
 * @brief VectorGraphics library "QUAD REL" command.
 */
#define LLVG_PATH_CMD_QUAD_REL 6

/*
 * @brief VectorGraphics library "CUBIC ABS" command.
 */
#define LLVG_PATH_CMD_CUBIC 7

/*
 * @brief VectorGraphics library "CUBIC REL" command.
 */
#define LLVG_PATH_CMD_CUBIC_REL 8

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions names redefinition
// --------------------------------------------------------------------------------

/*
 * @brief Macros to declare native functions
 */
#define LLVG_PATH_IMPL_initializePath       Java_ej_microvg_PathNatives_initializePath
#define LLVG_PATH_IMPL_appendPathCommand1   Java_ej_microvg_PathNatives_appendPathCommand___3BIIFF
#define LLVG_PATH_IMPL_appendPathCommand2   Java_ej_microvg_PathNatives_appendPathCommand___3BIIFFFF
#define LLVG_PATH_IMPL_appendPathCommand3   Java_ej_microvg_PathNatives_appendPathCommand___3BIIFFFFFF
#define LLVG_PATH_IMPL_reopenPath           Java_ej_microvg_PathNatives_reopenPath

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions
// --------------------------------------------------------------------------------

/*
 * @brief Initializes the path array.
 *
 * If the implementation requires a bigger array, it must return the number of required bytes.
 *
 * @param[in] path: the array to initialize
 * @param[in] length: the array size
 *
 * @return LLVG_SUCCESS on success or a value that indicates the minimal required size of the array.
 */
jint LLVG_PATH_IMPL_initializePath(jbyte *path, jint length);

/*
 * @brief Adds a command with 1 point parameter in the array.
 *
 * If the data (command and its parameters) cannot be added (out of memory), the implementation must return the
 * number of bytes required to add the data. The caller has to increase the array and call again the native method.
 *
 * @param[in] path: the array to update with the command and parameters.
 * @param[in] length: the array length.
 * @param[in] cmd: the command to add in the array.
 * @param[in] x: the command data 1.
 * @param[in] y: the command data 2.
 *
 * @return LLVG_SUCCESS on success or a value that indicates the number of bytes the array must be enlarged.
 */
jint LLVG_PATH_IMPL_appendPathCommand1(jbyte *path, jint length, jint cmd, jfloat x, jfloat y);

/*
 * @brief Adds a command with 2 points parameter in the array.
 *
 * @see #appendPathCommand(jbyte*, jint, jint, jfloat, jfloat)
 */
jint LLVG_PATH_IMPL_appendPathCommand2(jbyte *path, jint length, jint cmd, jfloat x1, jfloat y1, jfloat x2,
                                       jfloat y2);

/*
 * @brief Adds a command with 3 points parameter in the array.
 *
 * @see #appendPathCommand(jbyte*, jint, jint, jfloat, jfloat)
 */
jint LLVG_PATH_IMPL_appendPathCommand3(jbyte *path, jint length, jint cmd, jfloat x1, jfloat y1, jfloat x2,
                                       jfloat y2, jfloat x3, jfloat y3);

/*
 * @brief Opens again the closed path (the last path command is CMD_CLOSED for sure).
 *
 * The implementation resets the data offset at the end of the previous command.
 *
 * @param[in] path: the array to update.
 */
void LLVG_PATH_IMPL_reopenPath(jbyte *path);

// -----------------------------------------------------------------------------
// EOF
// -----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif // !defined LLVG_PATH_IMPL_H
