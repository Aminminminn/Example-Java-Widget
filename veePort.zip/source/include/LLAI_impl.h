/*
 * Copyright 2023-2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef LLAI_IMPL
#define LLAI_IMPL

#include <stdint.h> // verify if this is necessary

#ifdef __cplusplus
extern "C" {
#endif

#define LLAI_IMPL_TfLiteMicroSetUp 		Java_com_nxp_api_ai_natives_AINatives_TfLiteMicroSetUp
#define LLAI_IMPL_TfLiteMicroTearDown 	Java_com_nxp_api_ai_natives_AINatives_TfLiteMicroTearDown

#define LLAI_IMPL_GetInputTensorSize 	Java_com_nxp_api_ai_natives_AINatives_GetInputTensorSize
#define LLAI_IMPL_GetInputTensorDims	Java_com_nxp_api_ai_natives_AINatives_GetInputTensorDims
#define LLAI_IMPL_GetInputTensorType	Java_com_nxp_api_ai_natives_AINatives_GetInputTensorType

#define LLAI_IMPL_GetOutputTensorSize 	Java_com_nxp_api_ai_natives_AINatives_GetOutputTensorSize
#define LLAI_IMPL_GetOutputTensorDims 	Java_com_nxp_api_ai_natives_AINatives_GetOutputTensorDims
#define LLAI_IMPL_GetOutputTensorType	Java_com_nxp_api_ai_natives_AINatives_GetOutputTensorType

#define LLAI_IMPL_SetInputDataInt8		Java_com_nxp_api_ai_natives_AINatives_SetInputData_1Int8
#define LLAI_IMPL_SetInputDataUInt8		Java_com_nxp_api_ai_natives_AINatives_SetInputData_1UInt8
#define LLAI_IMPL_SetInputDataFloat32	Java_com_nxp_api_ai_natives_AINatives_SetInputData_1Float32

#define LLAI_IMPL_GetOutputDataInt8 	Java_com_nxp_api_ai_natives_AINatives_GetOutputData_1Int8
#define LLAI_IMPL_GetOutputDataUInt8 	Java_com_nxp_api_ai_natives_AINatives_GetOutputData_1UInt8
#define LLAI_IMPL_GetOutputDataFloat32	Java_com_nxp_api_ai_natives_AINatives_GetOutputData_1Float32

#define LLAI_IMPL_RunInference 			Java_com_nxp_api_ai_natives_AINatives_RunInference

/*
 * AI Functions
 */
int LLAI_IMPL_TfLiteMicroSetUp(char* model_path, int len, int arena_size);
int LLAI_IMPL_TfLiteMicroTearDown(int handle);

int LLAI_IMPL_GetInputTensorSize(int handle, int idx);
int LLAI_IMPL_GetInputTensorDims(int handle, int idx, int* sizes);
int LLAI_IMPL_GetInputTensorType(int handle, int idx);

int LLAI_IMPL_GetOutputTensorSize(int handle, int idx);
int LLAI_IMPL_GetOutputTensorDims(int handle, int idx, int* sizes);
int LLAI_IMPL_GetOutputTensorType(int handle, int idx);

int LLAI_IMPL_SetInputData_Int8(int handle, int idx, int8_t* src, int len);
int LLAI_IMPL_SetInputData_UInt8(int handle, int idx, uint8_t* src, int len);
int LLAI_IMPL_SetInputData_Float32(int handle, int idx, float* src, int len);

int LLAI_IMPL_GetOutputData_Int8(int handle, int idx, int8_t* dst, int len);
int LLAI_IMPL_GetOutputData_UInt8(int handle, int idx, uint8_t* dst, int len);
int LLAI_IMPL_GetOutputData_Float32(int handle, int idx, float* dst, int len);

int LLAI_IMPL_RunInference(int handle);

#ifdef __cplusplus
}
#endif
#endif
