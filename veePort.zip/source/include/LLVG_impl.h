/*
 * C
 *
 * Copyright 2022-2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#if !defined LLVG_IMPL_H
#define LLVG_IMPL_H

#if defined __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------
// Includes
// -----------------------------------------------------------------------------

#include <sni.h>

// -----------------------------------------------------------------------------
// Defines
// -----------------------------------------------------------------------------

/*
 * @brief Low-Level API VG major version.
 */
#define LLVG_MAJOR_VERSION 1

/*
 * @brief Low-Level API VG minor version.
 */
#define LLVG_MINOR_VERSION 6

/*
 * @brief Low-Level API VG patch version.
 */
#define LLVG_PATCH_VERSION 0

/*
 * @brief Value returned on success.
 */
#define LLVG_SUCCESS 0

/*
 * @brief Value returned on invalid path.
 */
#define LLVG_DATA_INVALID_PATH -1

/*
 * @brief Value returned on invalid data.
 */
#define LLVG_DATA_INVALID -2

/*
 * @brief Value returned when resource is closed.
 */
#define LLVG_RESOURCE_CLOSED -6

/*
 * @brief Value returned when an out of memory error occurs.
 */
#define LLVG_OUT_OF_MEMORY -9

/*
 * @brief Vector Graphics library's fill rules.
 */
#define LLVG_FILLTYPE_WINDING 0
#define LLVG_FILLTYPE_EVEN_ODD 1

/*
 * @brief Vector Graphics library's blending modes.
 */
#define LLVG_BLEND_SRC 0
#define LLVG_BLEND_SRC_OVER 1
#define LLVG_BLEND_DST_OVER 2
#define LLVG_BLEND_SRC_IN 3
#define LLVG_BLEND_DST_IN 4
#define LLVG_BLEND_DST_OUT 5
#define LLVG_BLEND_PLUS 6
#define LLVG_BLEND_SCREEN 7
#define LLVG_BLEND_MULTIPLY 8

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions names redefinition
// --------------------------------------------------------------------------------

/*
 * @brief Macros to declare native functions
 */
#define LLVG_IMPL_initialize       Java_ej_microvg_VectorGraphicsNatives_initialize

// --------------------------------------------------------------------------------
// Typedefs and Structures
// --------------------------------------------------------------------------------

/*
 * @brief Represents a MicroVG Image.
 *
 * This structure is used by several drawing functions which use an image as source
 * image.
 */
typedef struct {
	/*
	 * @brief Pointer on the image's data.
	 */
	void *data;

	/*
	 * @brief Size of the image's data.
	 */
	uint32_t size;
} MICROVG_Image;

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions
// --------------------------------------------------------------------------------

/*
 * @brief Initializes the implementation. This is the first native called by the library.
 */
void LLVG_IMPL_initialize(void);

// -----------------------------------------------------------------------------
// EOF
// -----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif // !defined LLVG_IMPL_H
