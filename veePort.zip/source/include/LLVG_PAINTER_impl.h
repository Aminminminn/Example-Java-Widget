/*
 * C
 *
 * Copyright 2023-2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#if !defined LLVG_PAINTER_IMPL_H
#define LLVG_PAINTER_IMPL_H

#if defined __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------
// Includes
// -----------------------------------------------------------------------------

#include <sni.h>

#include <LLVG_impl.h>
#include <LLVG_PATH_impl.h>
#include <LLVG_GRADIENT_impl.h>
#include <LLUI_DISPLAY.h>

// --------------------------------------------------------------------------------
// MicroVG native functions names redefinition
// --------------------------------------------------------------------------------
/*
 * @brief Macros to declare native functions
 */
#define LLVG_PAINTER_IMPL_drawPath Java_ej_microvg_PainterNatives_drawPath
#define LLVG_PAINTER_IMPL_drawGradient Java_ej_microvg_PainterNatives_drawGradient
#define LLVG_PAINTER_IMPL_drawString Java_ej_microvg_PainterNatives_drawString
#define LLVG_PAINTER_IMPL_drawStringGradient Java_ej_microvg_PainterNatives_drawGradientString
#define LLVG_PAINTER_IMPL_drawStringOnCircle Java_ej_microvg_PainterNatives_drawStringOnCircle
#define LLVG_PAINTER_IMPL_drawStringOnCircleGradient Java_ej_microvg_PainterNatives_drawGradientStringOnCircle
#define LLVG_PAINTER_IMPL_drawImage Java_ej_microvg_PainterNatives_drawImage

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions
// --------------------------------------------------------------------------------

/*
 * @brief Draws a path filled with the specified color (not the one of the Graphics Context).
 *
 * @param[in] gc: the destination
 * @param[in] path: the path's data
 * @param[in] x: the destination X coordinate
 * @param[in] y: the destination Y coordinate
 * @param[in] matrix: the deformation to apply
 * @param[in] fillRule: the fill type
 * @param[in] blend: the blend mode
 * @param[in] color: the color to apply (with an opacity)
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawPath(MICROUI_GraphicsContext *gc, jbyte *path, jint x, jint y, jfloat *matrix, jint fillRule,
                                jint blend, jint color);

/*
 * @brief Draws a path filled with a linear gradient.
 *
 * @param[in] gc: the destination
 * @param[in] path: the path's data
 * @param[in] x: the destination X coordinate
 * @param[in] y: the destination Y coordinate
 * @param[in] matrix: the deformation to apply
 * @param[in] fillRule: the fill type
 * @param[in] alpha: the global opacity to apply
 * @param[in] blend: the blend mode
 * @param[in] gradient: the gradient to apply
 * @param[in] gradientMatrix: the gradient deformation, may be null (means identity)
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawGradient(MICROUI_GraphicsContext *gc, jbyte *path, jint x, jint y, jfloat *matrix,
                                    jint fillRule, jint alpha, jint blend, jint *gradient, jfloat *gradientMatrix);

/*
 * @brief  Draws a string with the color of the Graphics Context.
 *
 * The top/left position of the first drawn character is placed at
 * coordinate x/y.
 *
 * @param[in] gc the MicroUI GraphicsContext target.
 * @param[in] text the array of characters to draw.
 * @param[in] faceHandle the font reference handle.
 * @param[in] size the height of the font in pixels.
 * @param[in] x the horizontal coordinate of the top/left of the first drawn character.
 * @param[in] y the vertical coordinate of the top/left of the first drawn character.
 * @param[in] matrix: deformation matrix, may be null (means identity)
 * @param[in] alpha the opacity level to apply to the character.
 * @param[in] blend the blend mode to use
 * @param[in] letterSpacing the extra letter spacing to use
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawString(MICROUI_GraphicsContext *gc, jchar *text, jint faceHandle, jfloat size, jfloat x,
                                  jfloat y, jfloat *matrix, jint alpha, jint blend, jfloat letterSpacing);

/*
 * @brief Draws a string with a linear gradient.
 *
 * @param[in] gc the MicroUI GraphicsContext target.
 * @param[in] text the array of characters to draw.
 * @param[in] faceHandle the font reference handle.
 * @param[in] size the height of the font in pixels.
 * @param[in] x the horizontal coordinate of the top/left of the first drawn character.
 * @param[in] y the vertical coordinate of the top/left of the first drawn character.
 * @param[in] matrix: deformation matrix, may be null (means identity)
 * @param[in] alpha the opacity level to apply to the character.
 * @param[in] blend the blend mode to use
 * @param[in] letterSpacing the extra letter spacing to use
 * @param[in] gradientData the gradient to apply
 * @param[in] gradientMatrix the gradient deformation, may be null (means identity)
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawStringGradient(MICROUI_GraphicsContext *gc, jchar *text, jint faceHandle, jfloat size,
                                          jfloat x, jfloat y, jfloat *matrix, jint alpha, jint blend,
                                          jfloat letterSpacing, jint *gradientData, jfloat *gradientMatrix);

/*
 * @brief Draws a string along a circle, with the color of the Graphics Context.
 *
 * @param[in] gc the MicroUI GraphicsContext target.
 * @param[in] text the array of characters to draw.
 * @param[in] faceHandle the font reference handle.
 * @param[in] size the height of the font in pixels.
 * @param[in] x the horizontal coordinate of the top/left of the first drawn character.
 * @param[in] y the vertical coordinate of the top/left of the first drawn character.
 * @param[in] matrix: deformation matrix, may be null (means identity)
 * @param[in] alpha the opacity level to apply to the character.
 * @param[in] blend the blend mode to use
 * @param[in] letterSpacing the extra letter spacing to use
 * @param[in] radius the radius of the circle
 * @param[in] direction the direction of the text along the circle
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawStringOnCircle(MICROUI_GraphicsContext *gc, jchar *text, jint faceHandle, jfloat size,
                                          jint x, jint y, jfloat *matrix, jint alpha, jint blend, jfloat letterSpacing,
                                          jfloat radius, jint direction);

/*
 * @brief Draws a string along a circle, with a linear gradient.
 *
 * @param[in] gc the MicroUI GraphicsContext target.
 * @param[in] text the array of characters to draw.
 * @param[in] faceHandle the font reference handle.
 * @param[in] size the height of the font in pixels.
 * @param[in] x the horizontal coordinate of the top/left of the first drawn character.
 * @param[in] y the vertical coordinate of the top/left of the first drawn character.
 * @param[in] matrix: deformation matrix, may be null (means identity)
 * @param[in] alpha the opacity level to apply to the character.
 * @param[in] blend the blend mode to use
 * @param[in] letterSpacing the extra letter spacing to use
 * @param[in] radius the radius of the circle
 * @param[in] direction the direction of the text along the circle
 * @param[in] gradientData the gradient to apply
 * @param[in] gradientMatrix the gradient deformation, may be null (means identity)
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawStringOnCircleGradient(MICROUI_GraphicsContext *gc, jchar *text, jint faceHandle,
                                                  jfloat size, jint x, jint y, jfloat *matrix, jint alpha, jint blend,
                                                  jfloat letterSpacing, jfloat radius, jint direction,
                                                  jint *gradientData, jfloat *gradientMatrix);

/*
 * @brief Draws an image with transformation and opacity. Optionally apply an animation and / or a color filtering.
 *
 * @param[in] gc the graphics context to draw on
 * @param[in] image the image to draw
 * @param[in] x the destination X coordinate
 * @param[in] y the destination Y coordinate
 * @param[in] matrix the transformation matrix to apply
 * @param[in] alpha the global opacity rendering value
 * @param[in] elapsedTime the elapsed time since the beginning of the animation, in milliseconds
 * @param[in] colorMatrix the color matrix used to transform colors, may be null (means no color deformation)
 *
 * @return LLVG_SUCCESS on success
 */
jint LLVG_PAINTER_IMPL_drawImage(MICROUI_GraphicsContext *gc, MICROVG_Image *image, jint x, jint y, jfloat *matrix,
                                 jint alpha, jlong elapsed, const float color_matrix[]);

// -----------------------------------------------------------------------------
// EOF
// -----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif // !defined LLVG_PATH_PAINTER_IMPL_H
