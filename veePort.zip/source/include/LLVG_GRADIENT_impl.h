/*
 * C
 *
 * Copyright 2022-2024 MicroEJ Corp. All rights reserved.
 * This library is provided in source code for use, modification and test, subject to license terms.
 * Any modification of the source code will break MicroEJ Corp. warranties on the whole library.
 */

#if !defined LLVG_GRADIENT_IMPL_H
#define LLVG_GRADIENT_IMPL_H

#if defined __cplusplus
extern "C" {
#endif

// -----------------------------------------------------------------------------
// Includes
// -----------------------------------------------------------------------------

#include <sni.h>

#include <LLVG_impl.h>

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions names redefinition
// --------------------------------------------------------------------------------

/*
 * @brief Macros to declare native functions
 */
#define LLVG_GRADIENT_IMPL_initializeGradient   Java_ej_microvg_GradientNatives_initializeGradient

// --------------------------------------------------------------------------------
// VectorGraphics library's native functions
// --------------------------------------------------------------------------------

/*
 * @brief Initializes the gradient array.
 *
 * If the implementation requires a bigger array, it must return the number of required bytes.
 *
 * The position array may be null; in that case, a linear distribution is set.
 *
 * @param[in] gradient: the array to initialize
 * @param[in] length: the array size
 * @param[in] colors: the colors to store
 * @param[in] count: the available number of colors
 * @param[in] positions: the colors positions or null to set default positions.
 * @param[in] xStart: the x-coordinate for the start of the gradient vector
 * @param[in] yStart: the y-coordinate for the start of the gradient vector
 * @param[in] xEnd: the x-coordinate for the end of the gradient vector
 * @param[in] yEnd: the y-coordinate for the end of the gradient vector
 *
 * @return LLVG_SUCCESS on success or a value that indicates the minimal required size of the array.
 */
jint LLVG_GRADIENT_IMPL_initializeGradient(jint *gradient, jint length, const jint *colors, jint count,
                                           const jfloat *positions, jfloat xStart, jfloat yStart, jfloat xEnd,
                                           jfloat yEnd);

// -----------------------------------------------------------------------------
// EOF
// -----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif // !defined LLVG_GRADIENT_IMPL_H
