/**
 * Copyright 2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef LLGPIO_IMPL
#define LLGPIO_IMPL

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LLGPIO_IMPL_init_gpio_pin Java_com_nxp_io_gpio_natives_GPIONatives_nativeInitGPIOPin
#define LLGPIO_IMPL_read_gpio_pin Java_com_nxp_io_gpio_natives_GPIONatives_nativeReadGPIOPin
#define LLGPIO_IMPL_write_gpio_pin Java_com_nxp_io_gpio_natives_GPIONatives_nativeWriteGPIOPin
#define LLGPIO_IMPL_toggle_gpio_pin Java_com_nxp_io_gpio_natives_GPIONatives_nativeToggleGPIOPin

/**
 * This function is used to initialize a GPIO pin
 * @param pin
 *          pin to initialize
 * @param direction
 *          direction of GPIO pin
 * @param pullConfig
 *          pull-up/down of GPIO pin
 *          (0 : disabled,
 *           1: pull up enabled,
 *           2: pull down enabled)
 * @return initialization status
 */
int32_t LLGPIO_IMPL_init_gpio_pin(uint32_t pin, uint32_t direction, uint32_t pullConfig);

/**
 * This function is used to read a GPIO pin
 * @param pin
 *          pin to read level from
 * @return value read or error status
 */
int32_t LLGPIO_IMPL_read_gpio_pin(uint32_t pin);

/**
 * This function is used to write a GPIO pin
 * @param pin
 *          pin to write level to
 * @param level
 *          level to write to pin
 * @return value read of written pin or error status
 */
int32_t LLGPIO_IMPL_write_gpio_pin(uint32_t pin, uint32_t level);

/**
 * This function is used to write a GPIO pin
 * @param pin
 *          pin to toggle level
 * @return value read of toggled pin or error status
 */
int32_t LLGPIO_IMPL_toggle_gpio_pin(uint32_t pin);

#ifdef __cplusplus
}
#endif
#endif
